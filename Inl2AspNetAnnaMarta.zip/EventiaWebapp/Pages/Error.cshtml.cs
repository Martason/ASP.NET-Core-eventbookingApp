using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventiaWebapp.Pages
{
    public class ErrorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
