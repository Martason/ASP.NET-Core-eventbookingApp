using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventiaWebapp.Areas.Identity.Pages.Account.Manage
{
    public class ConfirmAplicationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
